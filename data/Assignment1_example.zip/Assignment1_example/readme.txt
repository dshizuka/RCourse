Readme for iris.csv

This is data on flower morphology of 3 species of iris. The data were originally collected by Anderson (1935), and the data was used later by Fisher (1936). 

Variables:

Sepal.Length: length of sepals in cm
Sepal.Width: width of sepals in cm
Petal.Length: length of petal in cm
Petal.Width: width of petal in cm
Species: species name of the plant (Iris setosa, Iris versicolor, Iris virginica)


References:

Fisher, R. A. (1936) The use of multiple measurements in taxonomic problems. Annals of Eugenics, 7, Part II, 179–188.

The data were collected by Anderson, Edgar (1935). The irises of the Gaspe Peninsula, Bulletin of the American Iris Society, 59, 2–5.


