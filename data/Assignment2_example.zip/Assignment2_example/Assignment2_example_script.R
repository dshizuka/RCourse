### Script for Assignment 2 example
#This script will calculate the mean egg length and volume of coot eggs by nest from my 2006 egg measurement dataset.

dat=read.csv("data/EggMeasurements2006_clean.csv")
dat

#one way to calculate mean egg length by nest
means.table=tapply(dat$Length, dat$Nest, mean, na.rm=T)

#if I want that as a dataframe
means.dat=as.data.frame(means.table)
means.dat


#bonus: I'll calculate the egg volume and then get the means by nest
#the formula for calculating the volume of a coot egg comes from Reed, Clark & Vleck (2009-AmNat, 174)

dat$Volume=0.00536*(dat$Length*(dat$Width^2))+0.464
vol.means=tapply(dat$Volume, dat$Nest, mean, na.rm=T)
as.data.frame(vol.means)
