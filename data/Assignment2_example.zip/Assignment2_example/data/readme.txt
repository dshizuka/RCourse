## Info on EggMeasurements2006_clean.csv 

This data comes from measurements of eggs at nests of American Coots (Fulica americana) in lakes near Williams Lake, British Columbia in 2006. Nests were found by surveying the lakes every 1-2 days during the breeding season. Some (many) nests are found after more than one egg has been laid. After a nest is found, they are checked again every 1-2 days until the clutch is complete. When more than one egg appears in the nest per day, we infer that brood parasitism has occurred. Parasitic eggs are identified by visually comparing egg features with other eggs in the nest (egg appearance generally varies across females).

Columns are as follows:
- Nest: Nest ID number

- Egg_Number: The eggs ID, as numbered in the nest. The eggs are numbered in the order that they were found at the nest. However, when more than one egg has been laid in the nest between checks or if the nest is found after multiple eggs have been laid, then new batch of eggs are numbered in random order.

- Egg_ID: The nest x egg ID is combined to make individually unique ID for all eggs in the population.

- Hatched: 1 = the egg eventually hatched, 0 = egg did not hatch, either because the nest failed or because of dud egg.

- Egg Mass: Eggs were weighted with digital scale on the day they were found.

- Egg Length: Maximum length measured by calipers

- Egg Width: Maximum width measured by calipers.

- Lay_Date: The date the egg was laid, if known.