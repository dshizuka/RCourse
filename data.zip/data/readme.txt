items in the data folder:

boloria.csv and colias.csv - data from Bowden et al. (2015) from Module 5.1 Worked Example

SampleData.csv, SampleData_w_erros.csv, sex_chromo.csv, EggMeasurements_example.csv and EggMeasurements2006_clean.csv are for Module 4.